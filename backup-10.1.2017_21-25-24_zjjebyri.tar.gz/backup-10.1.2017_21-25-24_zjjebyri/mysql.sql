-- cPanel mysql backup
GRANT USAGE ON *.* TO 'zjjebyri'@'198.187.29.74' IDENTIFIED BY PASSWORD '*13CB126FB2AD1C0B7A1B0D194B042A9AB80EEA8D';
GRANT ALL PRIVILEGES ON `zjjebyri\_ecoinbest`.* TO 'zjjebyri'@'198.187.29.74';
GRANT USAGE ON *.* TO 'zjjebyri'@'host9.registrar-servers.com' IDENTIFIED BY PASSWORD '*13CB126FB2AD1C0B7A1B0D194B042A9AB80EEA8D';
GRANT ALL PRIVILEGES ON `zjjebyri\_ecoinbest`.* TO 'zjjebyri'@'host9.registrar-servers.com';
GRANT USAGE ON *.* TO 'zjjebyri'@'localhost' IDENTIFIED BY PASSWORD '*13CB126FB2AD1C0B7A1B0D194B042A9AB80EEA8D';
GRANT ALL PRIVILEGES ON `zjjebyri\_ecoinbest`.* TO 'zjjebyri'@'localhost';
GRANT USAGE ON *.* TO 'zjjebyri_ecoinbest'@'198.187.29.74' IDENTIFIED BY PASSWORD '*F4B6EA5F80A19245BD33D85FB8344317CEC8C7E6';
GRANT ALL PRIVILEGES ON `zjjebyri\_ecoinbest`.* TO 'zjjebyri_ecoinbest'@'198.187.29.74';
GRANT USAGE ON *.* TO 'zjjebyri_ecoinbest'@'host9.registrar-servers.com' IDENTIFIED BY PASSWORD '*F4B6EA5F80A19245BD33D85FB8344317CEC8C7E6';
GRANT ALL PRIVILEGES ON `zjjebyri\_ecoinbest`.* TO 'zjjebyri_ecoinbest'@'host9.registrar-servers.com';
GRANT USAGE ON *.* TO 'zjjebyri_ecoinbest'@'localhost' IDENTIFIED BY PASSWORD '*F4B6EA5F80A19245BD33D85FB8344317CEC8C7E6';
GRANT ALL PRIVILEGES ON `zjjebyri\_ecoinbest`.* TO 'zjjebyri_ecoinbest'@'localhost';
