<?php

include 'mysqli.class.php';

$config = array();
$config['host'] = 'localhost';
$config['user'] = 'ffkbe_chat';
$config['pass'] = 'f$vMyV74Jt**^rjkf*&^@@@%%%cmuEHYhs$$$$k999&fslkfjsl3ldklcvjlkdjlweo^&asdjlfasdfl';
$config['table'] = 'testing';

$db = new DB($config);

?>