<?php
include '../models/mysqli.class.php';

$config = array();
$config['host'] = 'localhost';
$config['user'] = 'ffkbe_api';
$config['pass'] = 'f$vMyV74mHJdh2fy9cKKDTH4Jt**^rjkf*&^@@@8*jlasdfjkalxcjvcx.sn.fasdfl';
$config['table'] = 'testing';

$db2 = new DB($config);

?>