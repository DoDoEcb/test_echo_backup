<?php 

	include_once "lib/Classes/Autoloads.class.php";

?>