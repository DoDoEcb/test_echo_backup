<script>
    window.location='painel/'
</script>
