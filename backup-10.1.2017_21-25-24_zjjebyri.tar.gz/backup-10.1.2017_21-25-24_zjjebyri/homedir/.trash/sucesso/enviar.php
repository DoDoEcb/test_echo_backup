<?php

$destinatario = "presidente@impactusbit.com"; //Seu email

$nome = $_POST['nome'];
$email = $_POST['email'];

$telefone = $_POST['telefone'];
$pais = $_POST['pais'];
$estado = $_POST['estado'];
$cidade = $_POST['cidade'];



if(isset($_FILES)){
	$allowedExtensions = array("pdf","doc","docx","gif","jpeg","jpg","png","rtf","txt");
	$files = array();
	foreach($_FILES as $name=>$file) {
		$file_name = $file['name']; 
		$temp_name = $file['tmp_name'];
		$file_type = $file['type'];
		$path_parts = pathinfo($file_name);
		$ext = $path_parts['extension'];
		if(!in_array($ext,$allowedExtensions)) {
			die("Arquivo $file_name com formato: $ext não pode ser enviado!");
		}
		array_push($files,$file);
	}
	
	// email fields: to, from, subject, and so on
	$to = $destinatario;
	$from = $email; 
	$subject = "Novo Cadastro - ".$nome; 
	$message = "<h2>Novo cadastro!</h2> <br>";
	$message .= "<p><strong>Nome: </strong>".$nome."</p>";
	$message .= "<p><strong>Email: </strong>".$email."</p>";
	$message .= "<p><strong>Telefone: </strong>".$telefone."</p>";
	$message .= "<p><strong>Pais: </strong>".$pais."</p>";
	$message .= "<p><strong>Estado: </strong>".$estado."</p>";
	$message .= "<p><strong>Cidade:</strong>".$cidade."</p>";


	$headers = "From: $from";
	
	// boundary 
	$semi_rand = md5(time()); 
	$mime_boundary = "==Multipart_Boundary_x{$semi_rand}x"; 
	 
	// headers for attachment 
	$headers .= "\nMIME-Version: 1.0\n" . "Content-Type: multipart/mixed;\n" . " boundary=\"{$mime_boundary}\""; 
	 
	// multipart boundary 
	$message = "This is a multi-part message in MIME format.\n\n" . "--{$mime_boundary}\n" . "Content-Type: text/html; charset=\"iso-8859-1\"\n" . "Content-Transfer-Encoding: 7bit\n\n" . $message . "\n\n"; 
	$message .= "--{$mime_boundary}\n";
	 
	// preparing attachments
	for($x=0;$x<count($files);$x++){
		$file = fopen($files[$x]['tmp_name'],"rb");
		$data = fread($file,filesize($files[$x]['tmp_name']));
		fclose($file);
		$data = chunk_split(base64_encode($data));
		$name = $files[$x]['name'];
		$message .= "Content-Type: {\"application/octet-stream\"};\n" . " name=\"$name\"\n" . 
		"Content-Disposition: attachment;\n" . " filename=\"$name\"\n" . 
		"Content-Transfer-Encoding: base64\n\n" . $data . "\n\n";
		$message .= "--{$mime_boundary}\n";
	}
	// send
	 
	$ok = mail($to, $subject, $message, $headers); 
	if ($ok) { 
		echo "Mensagem enviada! Aguarde..."; 
	} else { 
		echo "Ops, A mensagem não pode ser enviada,"; 
	}
}else{
	echo "Enviando... - ";
	$mensagem = "<h2>Atenção novo cadastro!</h2> <br>";
	$mensagem .= "<p><strong>Nome: </strong>".$nome."</p>";
	$mensagem .= "<p><strong>Email: </strong>".$email."</p>";

	$mensagem .= "<p><strong>Telefone: </strong>".$telefone."</p>";
	$mensagem .= "<p><strong>Pais: </strong>".$pais."</p>";
	$mensagem .= "<p><strong>Estado: </strong>".$estado."</p>";
	$mensagem .= "<p><strong>Cidade:</strong>".$cidade."</p>";

	if($acompanhante){
		$mensagem .= "<p><strong>Acompanhante:</strong> SIM </p>";
	}else{
		$mensagem .= "<p><strong>Acompanhante:</strong> Não selecionou </p>";
	}

	$headers = "MIME-Version: 1.1\r\n";
	$headers .= "Content-type: text/html; charset=UTF-8\r\n";
	$headers .= "From: ".$email."\r\n";
	$headers .= "Return-Path: ".$email."\r\n"; 

	$envio = mail($destinatario, "Novo Cadastro - ".$nome, $mensagem, $headers);

	if($envio){
		echo "Mensagem enviada... Aguarde!";
		header("Location: http://impactusbit.com");
	}
	else{
		echo "A mensagem não pode ser enviada. Volte e preencha novamente...";
	}
}

?>