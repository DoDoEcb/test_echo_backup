<?php
//give illusion of denying access to site dependendencies. 
header( 'Location: http://openex.pw/access_denied.php' ) ;
die();
?>