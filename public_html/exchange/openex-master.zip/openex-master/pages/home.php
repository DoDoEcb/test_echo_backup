
<div class="container">
	<div class="innertube">
		<h2>Welcome to</h2>
		<img src="assets/img/OpenEx-square.png" height="300" width="300" alt="OpenEx.pw"/>
		<br/>
		<h3>Cryptocurrency Exchange</h3>
	</div>
</div>
