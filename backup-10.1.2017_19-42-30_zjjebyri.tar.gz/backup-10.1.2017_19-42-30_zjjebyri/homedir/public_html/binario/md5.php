<?php 

echo base64_encode('hexa10000000');
?>