<!-- START FOOTER -->
<footer class="page-footer">
    <div class="footer-copyright">
        <div class="container">
            Copyright © 2017 <a class="grey-text text-lighten-4" href="http://www.lionbit.com" target="_blank">Impactusbit</a> All rights reserved.
            <span class="right"> Desenvolvido por <a class="grey-text text-lighten-4" href="http://impactusbit.com/">Acesso</a></span>
        </div>
    </div>


</footer>
<center><script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
    <!-- Bitcoin Moeda -->
    <ins class="adsbygoogle"
         style="display:block"
         data-ad-client="ca-pub-8922200598482613"
         data-ad-slot="8650973979"
         data-ad-format="auto"></ins>
    <!--<script>
        (adsbygoogle = window.adsbygoogle || []).push({});
    </script> </center>-->
