
<?php
require_once '../lib/block_io.php';
$apiKey = 'd9b6-bd2c-8b69-5fb7';
$pin = '30019130';
$version = 2; // the API version

$block_io = new BlockIo($apiKey, $pin, $version);






?>
