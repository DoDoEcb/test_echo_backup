<?php echo "<p class='notify-green' id='notify'>You are now logged out.</p>"; ?>
<meta http-equiv="refresh" content="2; URL=index.php">

