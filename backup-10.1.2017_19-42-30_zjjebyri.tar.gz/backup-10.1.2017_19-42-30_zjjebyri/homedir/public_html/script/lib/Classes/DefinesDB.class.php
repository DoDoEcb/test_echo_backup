<?php

class DefinesDB extends Historico{

	function __construct(){
	
		/*
		
		*/
		
	}

}
?>